<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundacion Albornoz Jimenez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="assets/imagenes/Fundacion.ico">
</head>
<!-- Fixed navbar -->
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">FAJ</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav pull-right">
                <li class="active">
                    <a href="index.php" class="btn">Ayuda</a>
                </li>
                <li>
                    <a href="dashboard.php" class="btn">Mascotas</a>
                </li>
                <li>
                    <a href="login.php" class="btn">Iniciar sesión</a>
                </li>
                <li>
                    <a href="registro.php" class="btn">Registrarse</a>
                </li>
            </ul>
        </div>
        <!--/.nav-collapse -->
    </div>
</nav>

<body>
    <div class="container px-5 px-lg-5 mt-5" id="main">
        <div class="row gx-5 gx-lg-5 row-cols-2 justify-content-center">
            <!-- Acerca de -->
            <div class="col 12 ">
                <div class="panel panel-default">
                    <div class="panel-heading panel-info">
                        <h3 class="text-center">¡Ayúdame!</h3>
                    </div>
                    <div class="class= card h-100">
                        <div class="card-body p-4 ">
                            <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                                Describe el problema con todo el detalle posible: un miembro
                                de nuestro equipo de asistencia se pondrá en contacto contigo muy pronto.
                            </p>
                            <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                                <strong>Aviso:</strong>
                                Este formulario solo sirve para informar de problemas técnicos y
                                otros errores de la página. 
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <fieldset>
                <form method="POST" action="acciones.php" enctype="multipart/form-data">
                    <div class="container" container-align="center">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Elige la categoría que mejor describa tu duda o problema:</label>
                                    <select class="form-control" name="categoria_id" required>
                                        <option disabled="disabled" selected>Categoria</option>
                                        <?php
                                        require 'vendor/autoload.php';
                                        $categoria = new fundacion\Categoria;
                                        $info_categoria = $categoria->mostrar();
                                        $cantidad = count($info_categoria);
                                        for ($i = 0; $i < $cantidad; $i++) {
                                            $item = $info_categoria[$i];
                                        ?>
                                            <option value="<?php print $item['id'] ?>"><?php print $item['nombre_categoria'] ?></option>
                                        <?php

                                        }
                                        ?>

                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="descripcion">Describa su duda o problema</label>
                            <textarea placeholder="Descríbalo detalladamente" minlength="15" maxlength="500" name="descripcion" id="descripcion" class="form-control" rows="4" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{15,500}" title="Descríbalo su duda o problema" required></textarea>
                        </div>

                        <label>Foto</label>
                        <br>
                        <label class="btn btn-primary btn-file glyphicon glyphicon-camera">
                            <input class="form-control" type="file" name="foto" style="display: none;">
                        </label>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="correo">Correo de la cuenta</label>
                                    <input type="email" minlength="10" maxlength="320" class="form-control" placeholder="Ingresa tu email" aria-describedby="emailHelp" name="correo" id="correo" pattern="[^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$]{10,320}" title="ingrese un correo valido" required>
                                </div>
                            </div>
                        </div>

                        <input type="submit" name="accion" class="btn btn-primary" value="Registrar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                </form>
            </fieldset>
        </div>
    </div> <!-- /container -->
    <!----------- Footer ------------>
    <footer>
        <br>
        <table class="table footer-table footer-table-td">
            <tbody>
                <tr>
                    <td><a class="a" style="text-decoration: none;" href="terminos&condiciones.php">Terminos & Condiciones</a></td>
                    <td><a class="a" style="text-decoration: none;" href="privacidad.php">Politica de privacidad</a></td>
                    <td><a class="a" style="text-decoration: none;" href="index.php">Acerca de</a></td>
                    <td><a class="a" style="text-decoration: none;" href="soporte.php">Ayuda</a></td>
                </tr>
                <tr>
                    <td><a class="a" style="text-decoration: none;" href="https://www.facebook.com/Fundaci%C3%B3n-Albornoz-Jim%C3%A9nez-1000658333438569/" target="_blank">Facebook</a></td>
                    <td><a class="a" style="text-decoration: none;" href="https://twitter.com/fundacion_j?t=h69P53_6IAjIUPqhJycW7Q&s=09" target="_blank">Twitter </a></td>
                    <td><a class="a" style="text-decoration: none;"> instagram </a></li>
                    <td>
                        <p class="a" style="text-decoration: none;"> Copyright (c) 2021</p>
                        </li>
                </tr>
            </tbody>
        </table>
    </footer>
</body>
<!-- JavaScript -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</html>