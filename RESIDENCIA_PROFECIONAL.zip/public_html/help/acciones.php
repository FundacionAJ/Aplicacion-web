<?php
require '../vendor/autoload.php';

$home = new fundacion\Ayuda;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($_POST['accion'] === 'Registrar') {

        if (empty($_POST['titulo']))
            exit('Completar titulo');

        if (empty($_POST['descripcion']))
            exit('Completar descripcion');

        $_params = array(
            'titulo' => $_POST['titulo'],
            'descripcion' => $_POST['descripcion'],
            'fecha' => date('Y-m-d')
        );

        $rpt = $home->registrar($_params);

        if ($rpt)
            header('Location: index.php');
        else
            print 'Error al registrar el home';
    }

    if ($_POST['accion'] === 'Actualizar') {

        if (empty($_POST['titulo']))
            exit('Completar titulo');

        if (empty($_POST['descripcion']))
            exit('Completar descripcion');
        $_params = array(
            'titulo' => $_POST['titulo'],
            'descripcion' => $_POST['descripcion'],
            'fecha' => date('Y-m-d'),
            'id' => $_POST['id'],
        );

        $rpt = $help->actualizar($_params);
        if ($rpt)
            header('Location: index.php');
        else
            print 'Error al actualizar el home';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $id = $_GET['id'];

    $rpt = $help->eliminar($id);

    if ($rpt)
        header('Location: index.php');
    else
        print 'Error al eliminar el home';
}

