<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Spartan:wght@300;600&display=swap" rel="stylesheet">
    <link rel="shorcut icon" type="image/x-icon" href="../assets/imagenes/Fundacion.ico">
    <script src="https://kit.fontawesome.com/ffec4ec2ed.js" crossorigin="anonymous"></script>
    <!-- css -->
    <style>
        :root {
            --dark: #16191C;
            --dark-x: #1E2126;
            --light: #ffffff;
        }

        body {
            font-family: 'Spartan', sans-serif;
            font-weight: 300;
            color: var(--light);
        }

        .text-light {
            color: var(--light) !important;
        }

        .bg-dark {
            background-color: var(--dark) !important;
        }

        .bg-dark-x {
            background-color: var(--dark-x);
        }

        .btn {
            min-height: 3.125rem;
            font-weight: 600;
        }

        .form-control {
            min-height: 3.125rem;
            line-height: initial;
        }

        .form-control:focus {
            background-color: var(--dark-x);
            outline: none;
        }

        .img-1 {
            background-image: url('../assets/imagenes/carrusel-1.jpg');
            background-size: cover;
            background-position: center;
        }

        .img-2 {
            background-image: url('../assets/imagenes/carrusel-2.jpg');
            background-size: cover;
            background-position: center;
        }

        .logo-redimension {
            max-width: 40%;
            max-height: 40%;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        .mascota-redimension {
            max-width: 200px;
            max-height: 200px;
            object-fit: cover;
        }
    </style>

</head>

<body class="bg-dark">
    <section>
        <div class="row g-0">
            <div class="col-lg-7  d-none d-lg-block">
                <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item img-1 min-vh-100 active" >
                            <div class="carousel-caption d-none d-md-block">
                                <h5 class="font-weight-bold">Nos encargamos de ayudar a animales de la calle</h5>
                                <a class="text-muted text-decoration-none">Fundación Albornoz Jiménez A.C.</a>
                            </div>
                        </div>
                        <div class="carousel-item img-2 min-vh-100">
                            <div class="carousel-caption d-none d-md-block">
                                <h5 class="font-weight-bold">Apoyamos a rescatistas independientes y asociaciones que lo necesiten</h5>
                                <a class="text-muted text-decoration-none">Fundación Albornoz Jiménez A.C.</a>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
            <div class="col-lg-5 bg-dark d-flex flex-column align-items-end min-vh-100">
                <div class="align-self-center w-100 px-lg-5 py-lg-4 p-2">
                    <h1 class="font-weight-bold mb-4 ">Recuperar contraseña</h1>
                    <form id="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" class="mb-5">

                        <div class="mb-4">
                            <label for="nombre_usuario" class="form-label font-weight-bold">Nombre Completo</label>
                            <input type="text" minlength="2" maxlength="100" class="form-control bg-dark-x border-0" placeholder="Ingresa tu nombre completo" name="nombre_usuario" id="nombre_usuario" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,100}" title="ingrese un nombre valido" required>

                        </div>
                        <div class="mb-4">
                            <label for="sobrenombre" class="form-label font-weight-bold">Sobrenombre</label>
                            <input type="text" minlength="2" maxlength="15" class="form-control bg-dark-x border-0" placeholder="Nombre de la cuenta" aria-describedby="nombresHelp" name="sobrenombre" id="sobrenombre" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,15}" title="ingrese un nombre valido" required>
                        </div>
                        <div class="mb-4">
                            <label for="correo" class="form-label font-weight-bold">Email</label>
                            <input type="email" minlength="10" maxlength="320" class="form-control bg-dark-x border-0" placeholder="Ingresa tu email" aria-describedby="emailHelp" name="correo" id="correo" pattern="[^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$]{10,320}" title="ingrese un correo valido" required>
                        </div>
                        <div class="mb-4">
                            <label for="telefono" class="form-label font-weight-bold">Telefono</label>
                            <input type="tel" minlength="10" maxlength="10" class="form-control bg-dark-x border-0" placeholder="Ingresa tu numero telefonico" aria-describedby="tellHelp" pattern="[0-9]{1,10}" name="telefono" id="telefono" title="ingrese un numero telefonico valido" required>
                        </div>

                        <?php if (!empty($error)) : ?>
                            <div class="mensaje">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        
                        <button type="submit" class="btn btn-primary w-100">Iniciar sesión</button>
                    </form>
                    <div class="text-center px-lg-5 pt-lg-3 pb-lg-4 p-4 mt-auto w-100">
                        <p class="d-inline-block mb-0">¿Recordaste tu cuenta?</p> <a href="../login.php" class="text-light font-weight-bold text-decoration-none">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
</body>

</html>