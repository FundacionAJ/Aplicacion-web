<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="assets/imagenes/Fundacion.ico">
</head>

<!-- Fixed navbar -->
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">FAJ</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav pull-right">
                <li class="active">
                    <a href="index.php" class="btn">Política de privacidad</a>
                </li>
                <li>
                    <a href="dashboard.php" class="btn">Mascotas</a>
                </li>
                <li>
                    <a href="login.php" class="btn">Iniciar sesión</a>
                </li>
                <li>
                    <a href="registro.php" class="btn">Registrarse</a>
                </li>
            </ul>
        </div>
        <!--/.nav-collapse -->
    </div>
</nav>

<body>

    <!--img-->
    <div class="container px-5 px-lg-5 mt-5" id="main">
        <div class="row gx-5 gx-lg-5 row-cols-2 justify-content-center">
            <div class="text-center">
                <img src="assets/imagenes/FundacionAJ.jpg" class="rounded mx-auto d-block img-thumbnail" alt="..."><br><br>
            </div>
            <!--cards-->
            <!-- Política de privacidad-->
            <div class="col 12 ">
                <div class="panel panel-default">
                    <div class="panel-heading panel-info">
                        <h3 class=" text-center ">Privacidad</h3>
                    </div>
                    <div class="class= card h-100">
                        <div class="card-body p-4 ">
                            <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                                De conformidad con los artículos 15 y 16 de la Ley Federal de
                                Protección de Datos Personales de las Particulares, le informamos
                                que Fundación Albornoz Jiménez A.C. es responsable de la recolección
                                y uso de sus datos personales, del uso que se le dé a los mismos y de
                                su protección.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading panel-info">
                    <h3 class=" text-center ">Sus datos personales se utilizarán para los siguientes fines:</h3>
                </div>
                <div class="class= card h-100">
                    <div class="card-body p-4 ">
                        <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                            Recopilamos los siguientes datos personales:
                            Nombre completo, Correo electrónico, Teléfono móvil y Dirección. <br><br>
                            Fundación Albornoz Jiménez se compromete a identificar, almacenar
                            y proteger sus datos personales en todo momento con las medidas de
                            seguridad legales, tecnológicas y administrativas que utilizamos ante
                            cualquier daño, pérdida, alteración, destrucción o uso, acceso o procesamiento
                            no autorizado, con respecto a dichos sistemas de confidencialidad y cualquier
                            incumplimiento inmediato de estas medidas de seguridad y / o confidencialidad,
                            en la medida que lesionen significativamente sus derechos morales. Celebrados
                            con las cláusulas de confidencialidad y protección de datos personales de esta
                            declaración de protección de datos, las mismas medidas de seguridad y confidencialidad
                            en el tratamiento de sus datos. <br>
                            Es importante tener en cuenta que puede utilizar sus derechos de protección de datos personales.
                        </p>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading panel-info">
                    <h3 class=" text-center ">Cambios en esta política de privacidad</h3>
                </div>
                <div class="class= card h-100">
                    <div class="card-body p-4 ">
                        <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                            Fundación Albornoz Jiménez A.C. se reserva el derecho de cambiar o actualizar
                            esta declaración de protección de datos en cualquier momento, en respuesta a
                            nuevas leyes, lineamientos internos o requisitos para la presentación o prestación
                            de nuestros servicios. <br><br>
                            Cualquier cambio a esta política de privacidad se enviará al correo electrónico
                            proporcionado.
                            Puede revocar su consentimiento para el procesamiento de sus datos personales en
                            cualquier momento, revise nuestra página de ayuda. <br><br>
                            Esta política de privacidad no se aplica a plataformas de terceros que no poseemos,
                            controlamos o administramos, como sitios web, servicios, aplicaciones o empresas de
                            terceros (Servicios de terceros). Le recomendamos que lea atentamente las políticas
                            de privacidad de los proveedores externos a los que accede. <br><br>
                            Finalmente, es importante recordar que en Fundación Albornoz Jiménez A.C. no utilizamos
                            COOKIES y WEB BEACONS para obtener información personal de usted.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- /container -->

    <!----------- Footer ------------>
    <footer>
        <table class="table footer-table footer-table-td">
            <tbody>
                <tr>
                    <td><a class="a" style="text-decoration: none;" href="terminos&condiciones.php">Terminos & Condiciones</a></td>
                    <td><a class="a" style="text-decoration: none;" href="privacidad.php">Politica de privacidad</a></td>
                    <td><a class="a" style="text-decoration: none;" href="index.php">Acerca de</a></td>
                    <td><a class="a" style="text-decoration: none;" href="soporte.php">Ayuda</a></td>
                </tr>
                <tr>
                    <td><a class="a" style="text-decoration: none;" href="https://www.facebook.com/Fundaci%C3%B3n-Albornoz-Jim%C3%A9nez-1000658333438569/" target="_blank">Facebook</a></td>
                    <td><a class="a" style="text-decoration: none;" href="https://twitter.com/fundacion_j?t=h69P53_6IAjIUPqhJycW7Q&s=09" target="_blank">Twitter </a></td>
                    <td><a class="a" style="text-decoration: none;"> instagram </a></li>
                    <td>
                        <p class="a" style="text-decoration: none;"> Copyright (c) 2021</p>
                        </li>
                </tr>
            </tbody>
        </table>
    </footer>

    <!-- JavaScript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>