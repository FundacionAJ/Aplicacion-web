<?php
session_start();


?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Fundación Albornoz Jiménez A.C.</title>

	<!--CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/estilos.css">
	<link rel="shorcut icon" type="image/x-icon" href="assets/imagenes/Fundacion.ico">
</head>

<body>

	<!-- Fixed navbar -->
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">FAJ</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li>
						<a href="index.php" class="btn">Acerca de</a>
					</li>
					<li class="active">
						<a href="dashboard.php" class="btn">Mascotas</a>
					</li>
					<li>
						<a href="login.php" class="btn">Iniciar sesion</a>
					</li>
					<li>
						<a href="register.php" class="btn">Registrarse</a>
					</li>
				</ul>
			</div>
			<!--/.nav-collapse -->
		</div>
	</nav>

	<div class="container px-4 px-lg-5 mt-5" id="main">
		<div class="row justify-content-center">
			<?php
			require 'vendor/autoload.php';
			$mascota = new fundacion\Mascota;
			$info_mascota = $mascota->mostrarPorEstatus();
			$cantidad = count($info_mascota);
			if ($cantidad > 0) {
				for ($i = 0; $i < $cantidad; $i++) {
					$item = $info_mascota[$i];
			?>
					<div class="col-md-3">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h1 class="text-center titulo-pelicula"><?php print $item['nombre_m'] ?></h1>
							</div>
							<div class="panel-body img-responsive center-block">
								<?php
								$foto = 'upload/' . $item['foto'];
								if (file_exists($foto)) {
								?>
									<img class="img-resposive center-block" src="<?php print $foto; ?>">
								<?php } else { ?>
									<img class="img-resposive center-block" src="assets/imagenes/not-found.jpg">
								<?php } ?>
							</div>
							<div class="panel-footer">
								<a href="login.php" class="btn btn-success btn-block">
									<span class="glyphicon "></span> Ver mas
								</a>
							</div>
						</div>
					</div>
				<?php
				}
			} else { ?>
				<h4>No hay registros</h4>

			<?php } ?>

		</div>
	</div> <!-- /container -->


	<!-- JavaScript-->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

</body>

</html>