<?php
          require '../../../vendor/autoload.php';
          $id = $_GET['id'];
          $suspender = new fundacion\Usuario;
          $info_suspender= $suspender->suspender($id);
          header('Location: index.php');    
         
?>