<?php session_start();

if (isset($_SESSION['administrador'])) {

  require '../../../conexion.php';
  $email_sesion = $_SESSION['administrador'];
  $query_sesion = $conexion->prepare("SELECT * FROM administrador WHERE correo ='$email_sesion'");
  $query_sesion->execute();
  $sesion_administradores = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
  foreach ($sesion_administradores as $sesion_administrador) {
    $sobrenombre = $sesion_administrador['sobrenombre'];
  }
?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="../../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="../../../assets/imagenes/Fundacion.ico">
    <link rel="stylesheet" type="text/css" href="../../../DataTables/datatables.min.css" />
    <link rel="stylesheet" type="text/css" href="../../../DataTables/Responsive-2.2.9/css/responsive.dataTables.min.css" />
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Regresar</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li class="active" class="dropdown">
              <a href="index.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Usuarios<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="index.php">General</a></li>
                <li><a href="desactivas.php">Desactivas</a></li>
                <li><a href="suspendidas.php">Suspendidas</a></li>
                <li><a href="actualizadas.php">Actualizadas</a></li>
                <li><a href="grafica.php">Grafica</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="../actualizar_administrador.php">Mis datos</a></li>
                <li><a href="../actualizar_clave.php">Cambiar contraseña</a></li>
                <li><a href="../../../Cerrar_session.php">Salir</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">
      <div class="row">
        <div class="col 12">
          <fieldset>
            <legend>Cuentas activas</legend>
            <table id="tablax" class="table table-bordered display responsive nowrap" cellspacing="0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Usuario</th>
                  <th>Correo</th>
                  <th>Estatus</th>
                  <th>Activar</th>
                  <th>Suspender</th>
                  <th>Actualizar</th>
                </tr>
              </thead>
              <tbody>
                <?php
                require '../../../vendor/autoload.php';
                $usuario = new fundacion\Usuario;
                $info_usuario = $usuario->mostrarActivas();

                $cantidad = count($info_usuario);
                if ($cantidad > 0) {
                  $c = 0;
                  for ($i = 0; $i < $cantidad; $i++) {
                    $c++;
                    $item = $info_usuario[$i];
                ?>
                   <tr>
                      <td><?php print $c ?></td>
                      <td><?php print $item['nombre_usuario'] ?></td>
                      <td><?php print $item['correo'] ?></td>
                      <td><?php print $item['nombre_actual'] ?></td>

                      <td class="text-center">
                        <a href="activar.php?id=<?php print $item['id'] ?>" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-ok"></span></a>
                      </td>
                      <td class="text-center">
                        <a href="suspender.php?id=<?php print $item['id'] ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-remove"></span></a>
                      </td>
                      <td class="text-center">
                        <a href="info_actualizar.php?id=<?php print $item['id'] ?>" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-refresh"></span></a>
                      </td>
                    </tr>

                  <?php
                  }
                } else {

                  ?>
                  <tr>
                    <td colspan="6">No hay registros</td>
                  </tr>

                <?php } ?>

              </tbody>
            </table>
            
          </fieldset>
        </div>
      </div>
    </div> <!-- /container -->

    <!-- JavaScript -->
    <script src="../../../assets/js/jquery.min.js"></script>
    <script src="../../../assets/js/bootstrap.min.js"></script>
    <!-- Data tables -->

    <script type="text/javascript" src="../../../DataTables/datatables.min.js"></script>
    <script type="text/javascript" src="../../../DataTables/Responsive-2.2.9/js/dataTables.responsive.min.js"></script>
    <script>
      $(document).ready(function() {
        $('#tablax').DataTable({
          responsive: true,
          language: {
            processing: "Tratamiento en curso...",
            search: "Buscar&nbsp;:",
            lengthMenu: "Agrupar de _MENU_ registros",
            info: "Mostrando del registro _START_ al _END_ de un total de _TOTAL_ registros",
            infoEmpty: "No existen datos.",
            infoFiltered: "(filtrado de _MAX_ elementos en total)",
            infoPostFix: "",
            loadingRecords: "Cargando...",
            zeroRecords: "No se encontraron datos con tu busqueda",
            emptyTable: "No hay datos disponibles en la tabla.",
            paginate: {
              first: "Primero",
              previous: "Anterior",
              next: "Siguiente",
              last: "Ultimo"
            },
            aria: {
              sortAscending: ": active para ordenar la columna en orden ascendente",
              sortDescending: ": active para ordenar la columna en orden descendente"
            }
          }
        });
      });
    </script>

  </body>

  </html>
<?php
} else {
  header('Location: ../../../login.php'); 
  die();
}

?>