<?php
require '../vendor/autoload.php';

$mascota = new fundacion\Mascota;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($_POST['accion'] === 'Registrar') {

        if (empty($_POST['nombre_m']))
            exit('Completar nombre');

        if (empty($_POST['sexo']))
        exit('Completar campo sexo');

        if (empty($_POST['color']))
        exit('Completar campo color');

        if (empty($_POST['edad']))
        exit('Completar campo edad');

        if (empty($_POST['estatus_id']))
            exit('Completar campo estatus');

        if (!is_numeric($_POST['estatus_id']))
            exit('Seleccionar un estatus válida');

        if (empty($_POST['descripcion']))
            exit('Completar campo descripcion');

        if (empty($_POST['especie_id']))
            exit('Seleccionar una especie');
/*--!is_numeric--*/
        if (!is_numeric($_POST['especie_id']))
            exit('Seleccionar una especie válida');

        if (empty($_POST['raza']))
        exit('Completar campo raza');

        if (empty($_POST['telefono_dueno_ant']))
        exit('Completar campo telefono dueño anterior');

        if (empty($_POST['nombre_dueno_ant']))
        exit('Completar campo nombre dueño anterior');


        $_params = array(
            'nombre_m' => $_POST['nombre_m'],
            'sexo' => $_POST['sexo'],
            'color' => $_POST['color'],
            'edad' => $_POST['edad'],
            'estatus_id' => $_POST['estatus_id'],
            'descripcion' => $_POST['descripcion'],
            'foto' => subirFoto(),
            'especie_id' => $_POST['especie_id'],
            'raza' => $_POST['raza'],
            'telefono_dueno_ant' => $_POST['telefono_dueno_ant'],
            'nombre_dueno_ant' => $_POST['nombre_dueno_ant'],
            'fecha' => date('Y-m-d')

        );

        $rpt = $mascota->registrar($_params);

        if ($rpt)
            header('Location: mascota/index.php');
        else
            print 'Error al registrar una mascota';
    }

    if ($_POST['accion'] === 'Actualizar') {

        if (empty($_POST['nombre_m']))
            exit('Completar campo nombre');

        if (empty($_POST['sexo']))
            exit('Completar campo sexo');

        if (empty($_POST['color']))
            exit('Completar campo color');

        if (empty($_POST['edad']))
            exit('Completar campo edad');

        if (empty($_POST['estatus_id']))
            exit('seleccionar un estatus');

        if (!is_numeric($_POST['estatus_id']))
            exit('Seleccionar un estatus válida');

        if (empty($_POST['descripcion']))
            exit('Completar campo descripcion');

        if (empty($_POST['especie_id']))
            exit('Seleccionar una especie');

        if (!is_numeric($_POST['especie_id']))
            exit('Seleccionar una especie válida');

        if (empty($_POST['raza']))
            exit('Completar campo raza');

        if (empty($_POST['telefono_dueno_ant']))
            exit('Completar campo telefono');

        if (empty($_POST['nombre_dueno_ant']))
            exit('Completar campo nombre de dueño anterior');


        $_params = array(
            'nombre_m' => $_POST['nombre_m'],
            'sexo' => $_POST['sexo'],
            'color' => $_POST['color'],
            'edad' => $_POST['edad'],
            'estatus_id' => $_POST['estatus_id'],
            'descripcion' => $_POST['descripcion'],
            'especie_id' => $_POST['especie_id'],
            'raza' => $_POST['raza'],
            'fecha' => date('Y-m-d'),
            'telefono_dueno_ant' => $_POST['telefono_dueno_ant'],
            'nombre_dueno_ant' => $_POST['nombre_dueno_ant'],
            'id' => $_POST['id']
        );

        if (!empty($_POST['foto_temp']))
            $_params['foto'] = $_POST['foto_temp'];

        if (!empty($_FILES['foto']['name']))
            $_params['foto'] = subirFoto();

        $rpt = $mascota->actualizar($_params);
        if ($rpt)
            header('Location: mascota/index.php');
        else
            print 'Error al actualizar una mascota';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $id = $_GET['id'];

    $rpt = $mascota->eliminar($id);

    if ($rpt)
        header('Location: mascota/index.php');
    else
        print 'Error al eliminar una mascota';
}


function subirFoto()
{

    $carpeta = __DIR__ . '/../upload/';

    $archivo = $carpeta . $_FILES['foto']['name'];

    move_uploaded_file($_FILES['foto']['tmp_name'], $archivo);

    return $_FILES['foto']['name'];
}
