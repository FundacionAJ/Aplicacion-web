<?php session_start();
require_once '../../conexion.php';
if (isset($_SESSION['usuario'])) {
    $email_sesion = $_SESSION['usuario'];
    $query_sesion = $conexion->prepare("SELECT * FROM usuarios WHERE correo ='$email_sesion'");
    $query_sesion->execute();
    
    $sesion_usuarios = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
    foreach ($sesion_usuarios as $sesion_usuario) {
        $correo = $sesion_usuario['correo'];
        $pwd = $sesion_usuario['clave'];
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $claveactual = $_POST['claveactual'];
        $clave = $_POST['clave'];
        $clave2 = $_POST['clave2'];

        $claveactual = hash('sha512', $claveactual);
        $clave = hash('sha512', $clave);
        $clave2 = hash('sha512', $clave2);

        $error = '';
        if (empty($claveactual) or empty($clave) or empty($clave2)) {

            $error .= '<i style="color: red;">Favor de rellenar todos los campos</i>';
        }


        if ($claveactual != $pwd) {
            $error .= '<i style="color: red;"> Su contraseña no es correcta</i>';
        }

        if ($clave != $clave2) {
            $error .= '<i style="color: red;"> Las contraseñas no son iguales</i>';
        }

        if (($claveactual == $clave) && ($claveactual == $clave2)) {
            $error .= '<i style="color: red;"> No puede cambiar la contraseña por la que tiene actualmente </i>';
        }

        if ($error == '') {
            
            $statement = $conexion->prepare("UPDATE `usuarios` SET `clave`=:clave WHERE `correo`= :correo ");
            $statement->execute(array(
                ':clave' => $clave,
                ':correo'=> $correo
            ));

            $error .= '<i style="color: green;">Usuario actualizado exitosamente</i>';
        }
    }
} else {
    header('Location: ../../login.php'); 
  die();
}

require 'cambiar_clave.php';
