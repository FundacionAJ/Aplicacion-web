<?php session_start();
require_once '../../conexion.php';
if (isset($_SESSION['usuario'])) {
    $email_sesion = $_SESSION['usuario'];
    $query_sesion = $conexion->prepare("SELECT * FROM usuarios WHERE correo ='$email_sesion'");
    $query_sesion->execute();

    $sesion_usuarios = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
    foreach ($sesion_usuarios as $sesion_usuario) {
        $correo = $sesion_usuario['correo'];
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $clave = $_POST['clave'];
        $clave2 = $_POST['clave2'];

        $clave = hash('sha512', $clave);
        $clave2 = hash('sha512', $clave2);

        $error = '';
        if (empty($clave) or empty($clave2)) {

            $error .= '<i style="color: red;">Favor de rellenar todos los campos</i>';
        }


        if ($clave != $clave2) {
            $error .= '<i style="color: red;"> Las contraseñas no son iguales</i>';
        }


        if ($error == '') {

            $statement = $conexion->prepare("DELETE FROM `usuarios` WHERE `correo`= :correo AND `clave`=:clave ");
            $statement->execute(array(
                ':clave' => $clave,
                ':correo' => $correo
            ));

        }
    }
} else {
    header('Location: ../../login.php');
    die();
}

require 'eliminar.php';
