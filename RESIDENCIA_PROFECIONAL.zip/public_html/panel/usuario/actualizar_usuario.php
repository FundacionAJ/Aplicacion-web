<?php session_start();
if (isset($_SESSION['usuario'])) {
    require_once '../../conexion.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $nombre_usuario = $_POST['nombre_usuario'];
        $sobrenombre = $_POST['sobrenombre'];
        $correo = $_POST['correo'];
        $telefono = $_POST['telefono'];
        $direccion = $_POST['direccion'];

        $error = '';
        if (empty($nombre_usuario) or empty($sobrenombre) or empty($correo) or empty($telefono) or empty($direccion)) {

            $error .= '<i style="color: red;">Favor de rellenar todos los campos</i>';
        }



        if ($error == '') {
            $statement = $conexion->prepare("UPDATE `usuarios` SET `nombre_usuario`=:nombre_usuario,`sobrenombre`=:sobrenombre,`correo`=:correo,`telefono`=:telefono,`direccion`=:direccion  WHERE `correo`=:correo");
            $statement->execute(array(

                ':nombre_usuario' => $nombre_usuario,
                ':sobrenombre' => $sobrenombre,
                ':correo' => $correo,
                ':telefono' => $telefono,
                ':direccion' => $direccion


            ));
            $error .= '<i style="color: green;">Usuario actualizado exitosamente</i>';
        }
    }
} else {
    header('Location: ../../login.php');
    die();
}

require 'index.php';
