<?php session_start();

if (isset($_SESSION['administrador'])) {

  require '../../conexion.php';
  require '../../vendor/autoload.php';
  $email_sesion = $_SESSION['administrador'];
  $query_sesion = $conexion->prepare("SELECT * FROM administrador WHERE correo ='$email_sesion'");
  $query_sesion->execute();
  $sesion_administradores = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
  foreach ($sesion_administradores as $sesion_administrador) {
    $sobrenombre = $sesion_administrador['sobrenombre'];
  }

  if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $mascota = new fundacion\Mascota;
    $resultado = $mascota->mostrarPorId($id);

    if (!$resultado)
      header('Location: index.php');
  } else {
    header('Location: index.php');
  }
?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundacion Albornoz Jimenez A.C.</title>

    <!--CSS -->
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="../../assets/imagenes/favicon.ico">
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../dashboard.php">Fundacion Albornoz Jimenez A.C. </a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li>
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Estatus de Mascotas <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="Disponibles.php">Disponibles</a></li>
                <li><a href="Nodisponible.php"> No Disponibles</a></li>
                <li><a href="Adoptados.php">Adoptados</a></li>
              </ul>
            </li>
            <li class="active">
              <a href="index.php" class="btn">Mascotas</a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Mis datos</a></li>
                <li><a href="#">Cambiar contraseña</a></li>
                <li><a href="../../Cerrar_session.php">Salir</a></li>
              </ul>
            </li>
          </ul>




        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">
      <div class="row">
        <div class="col-md-12">
          <fieldset>
            <legend>Datos de la Mascota</legend>
            <form method="POST" action="../acciones.php" enctype="multipart/form-data">
              <input type="hidden" name="id" value="<?php print $resultado['id'] ?>">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">

                    <label>Nombre</label>
                    <input value="<?php print $resultado['nombre_m'] ?>" type="text" class="form-control" name="nombre_m" required>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Sexo</label>
                    <select value="<?php print $resultado['sexo'] ?>" type="text" class="form-control" name="sexo" required>
                      <option value="Macho">Macho</option>
                      <option value="Hembra">Hembra</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">

                    <label>Color</label>
                    <input value="<?php print $resultado['color'] ?>" type="text" class="form-control" name="color" required>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">

                    <label>Edad</label>
                    <input value="<?php print $resultado['edad'] ?>" type="text" class="form-control" name="edad" required>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">


                    <label>Estatus</label>
                    <select class="form-control" name="estatus_id" required>
                      <!-- <option value="">--SELECCIONE--</option>*/ -->
                      <?php
                      require '../../vendor/autoload.php';
                      $estatus = new fundacion\Estatus;
                      $info_estatus = $estatus->mostrar();
                      $cantidad = count($info_estatus);
                      for ($i = 0; $i < $cantidad; $i++) {
                        $item = $info_estatus[$i];
                      ?>
                        <option value="<?php print $item['id_estatus'] ?>" <?php print $resultado['estatus_id'] == $item['id_estatus'] ? 'selected' : '' ?>><?php print $item['nombre_s'] ?></option>
                      <?php

                      }
                      ?>
                    </select>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Descripción</label>
                    <textarea class="form-control" minlength="170" maxlength="200" name="descripcion" id="" cols="3" required><?php print $resultado['descripcion'] ?></textarea>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Especie</label>
                    <select class="form-control" name="especie_id" required>
                      <!-- <option value="">--SELECCIONE--</option> -->
                      <?php
                      require '../../vendor/autoload.php';
                      $categoria = new fundacion\Especie;
                      $info_categoria = $categoria->mostrar();
                      $cantidad = count($info_categoria);
                      for ($i = 0; $i < $cantidad; $i++) {
                        $item = $info_categoria[$i];
                      ?>
                        <option value="<?php print $item['id'] ?>" <?php print $resultado['especie_id'] == $item['id'] ? 'selected' : '' ?>><?php print $item['nombre_e'] ?></option>
                      <?php

                      }
                      ?>
                    </select>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Raza</label>
                    <input value="<?php print $resultado['raza'] ?>" type="text" class="form-control" name="raza" required>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Numero Telefonico de Contacto</label>
                    <input value="<?php print $resultado['telefono_dueno_ant'] ?>" type="text" class="form-control" name="telefono_dueno_ant" required>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Nombre de la Persona de Contacto</label>
                    <input value="<?php print $resultado['nombre_dueno_ant'] ?>" type="text" class="form-control" name="nombre_dueno_ant" required>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Foto</label>
                    <input type="file" class="form-control" name="foto">
                    <input type="hidden" name="foto_temp" value="<?php print $resultado['foto'] ?>">
                  </div>
                </div>
              </div>
              <input type="submit" class="btn btn-primary" name="accion" value="Actualizar">
              <a href="index.php" class="btn btn-default">Cancelar</a>
            </form>
          </fieldset>

        </div>
      </div>

    </div> <!-- /container -->


    <!-- JavaScript -->
    <script src="../../assets/js/jquery.min.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script type='text/javascript'>
      $(function() {
        $(document).bind("contextmenu", function(e) {
          return false;
        });
      });
    </script>
  </body>

  </html>
<?php
} else {
  header('Location: ../../login.php');
  die();
}

?>