<?php

ob_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=sub, initial-scale=1.0">

  <!--  CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
  <style>
    .watermark {
      position: absolute;
      margin-top: -195px;
      margin-left: -290px;

      left: 60%;
      top: 50%;

      bottom: 10cm;


      /** Cambiar las dimensiones de la imagen **/
      width: 10cm;
      height: 10cm;

      /** Tu marca de agua debe estar detrás de cada contenido **/
      z-index: -1000;
      opacity: 0.3;
    }
  </style>



</head>

<body>

  <div class="watermark">
    <img src="../../assets/imagenes/Fundacion.jpeg" height="100%" width="100%" />
  </div>

  <div class="container" id="main">


    <div class="row">
      <div class="col-md-12">
        <fieldset>
          <legend>REPORTE DE MASCOTAS ADOPTADAS</legend>
          <BR></BR>
          <table id="tablax" class="table table-bordered display responsive nowrap" cellspacing="0">
            <thead>
              <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Sexo</th>
                <th>Color</th>
                <th>Edad</th>
                <th>Estatus</th>

                <th>Especie</th>
                <th>raza</th>
                <th>Fecha de Registro</th>
                <th>Contacto Dueño Anterior</th>
                <th>Nombre Dueño Anterior</th>
                <th class="text-center">Foto</th>

              </tr>
            </thead>
            <tbody>
              <?php
              require '../../vendor/autoload.php';
              $mascota = new fundacion\Mascota;
              $info_mascota = $mascota->mostraradoptados();


              $cantidad = count($info_mascota);
              if ($cantidad > 0) {
                $c = 0;
                for ($i = 0; $i < $cantidad; $i++) {
                  $c++;
                  $item = $info_mascota[$i];
              ?>


                  <tr>
                    <td><?php print $c ?></td>
                    <td><?php print $item['nombre_m'] ?></td>
                    <td><?php print $item['sexo'] ?></td>
                    <td><?php print $item['color'] ?></td>
                    <td><?php print $item['edad'] ?></td>
                    <td><?php print $item['nombre_s'] ?></td>

                    <td><?php print $item['nombre_e'] ?></td>
                    <td><?php print $item['raza'] ?></td>
                    <td><?php print $item['fecha'] ?></td>
                    <td><?php print $item['telefono_dueno_ant'] ?></td>
                    <td><?php print $item['nombre_dueno_ant'] ?></td>
                    <td class="text-center">
                      <?php
                      $foto = '../../upload/' . $item['foto'];
                      if (file_exists($foto)) {
                      ?>
                        <img src="<?php print $foto; ?>" width="70">
                      <?php } else { ?>
                        SIN FOTO
                      <?php } ?>
                    </td>


                  </tr>

                <?php
                }
              } else {

                ?>
                <tr>
                  <td colspan="6">NO HAY REGISTROS</td>
                </tr>

              <?php } ?>


            </tbody>

          </table>
        </fieldset>
      </div>
    </div>

  </div> <!-- /container -->







</body>

</html>


<?php
$html = ob_get_clean();
//echo $html;
require_once("../../dompdf/autoload.inc.php");

use Dompdf\Dompdf;

$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled' => true));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('A4,', 'landscape');
$name = 'Reporte-Mascotas-Adoptadas-' . date('m-d-Y_hia');

$dompdf->render();
$dompdf->stream($name, array("Attachment" => TRUE));

?>