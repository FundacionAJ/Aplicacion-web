<?php
          require '../../vendor/autoload.php';
          $id = $_GET['id'];
          $pedido = new fundacion\Solicitud;
          $info_actualizar= $pedido->denegar($id);
          header('Location: index.php'); 
                 
          
?>