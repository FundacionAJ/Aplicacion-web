<?php
          require '../../vendor/autoload.php';
          $id = $_GET['id'];
          $pedido = new fundacion\Solicitud;
          $info_actualizar= $pedido->aprobar($id);
          header('Location: index.php'); 
                 
          
?>