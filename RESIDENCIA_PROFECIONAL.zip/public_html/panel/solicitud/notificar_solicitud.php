<?php
$correo = $_GET['correo'];
     ini_set( 'display_errors', 1 );
     error_reporting( E_ALL );
   
     $to = "charliyo17@gmail.com";
     $subject = "SEGUIMIENTO DE ADOPCION DE MASCOTA";
     $headers = "From: FundacionAlbornozJimenez@gmail.com";
     $message = "Me dirijo a usted para informarle EL SEGUIMIENTO sobre la solicitud de ADOPCION DE MASCOTAS." . "\r\n";
     $message .= "Se dara seguimiento en la Fundacion en la ubicacion en Ejército Nacional 345 Col. Granada C.P 11520 Miguel Hidalgo CDMX,
     " . "\r\n";
     $message .= "Si presenta alguna duda favor de llamr a TEL: 5521552012" . "\r\n";
     $message .= "Atentamente.
     Fundacion Albornoz Jimenez" . "\r\n";
     mail($to,$subject,$message, $headers);
     header('Location: index.php');
 ?>