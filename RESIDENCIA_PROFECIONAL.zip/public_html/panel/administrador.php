<?php session_start();

if (isset($_SESSION['administrador'])) {
  require '../conexion.php';

  $email_sesion = $_SESSION['administrador'];
  $query_sesion = $conexion->prepare("SELECT * FROM administrador WHERE correo ='$email_sesion'");
  $query_sesion->execute();
  $sesion_administradores = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
  foreach ($sesion_administradores as $sesion_administrador) {
    $sobrenombre = $sesion_administrador['sobrenombre'];
  }
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundacion Albornoz Jimenez A.C.</title>
     <style>
    div.gallery {
    margin: 80px;
    float: left;
    width: 220px;
    }

    div.gallery:hover {
   
    }

    div.gallery img {
    width: 150%;
    height: 50%;
    }

    div.desc {
    padding: 15px;
    text-align: center;
    }
  </style>

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <link rel="stylesheet" href="../assets/css/box.css">
    <link rel="icon" href="../assets/imagenes/logo.ico">
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>

        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li>
              <a href="solicitud/index.php" class="btn">Solicitudes</a>
            </li>
            <li class="dropdown">
              <a href="index.php" class="dropdown-toggle" class="active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php print "Reportes de Solicitudes"; ?><span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="../reportes_solicitud/index.php">GENERAL</a></li>
                <li><a href="../reportes_solicitud/index_aceptadas.php">ACEPTADAS</a></li>
                <li><a href="../reportes_solicitud/index_rechazadas.php">RECHAZADAS</a></li>
              </ul>
            </li>
            <li>
              <a href="../help/index.php" class="btn">Reportes de ayuda</a>
            </li>
            <li>
              <a href="mascota/index.php" class="btn">Administar Mascotas</a>
            </li>
            <li>
              <a href="administrador/usuarios/index.php" class="btn">Administar Usuarios</a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="administrador/actualizar_administrador.php">Mis datos</a></li>
                <li><a href="administrador/actualizar_clave.php">Cambiar contraseña</a></li>
                <li><a href="../Cerrar_session.php">Salir</a></li>
              </ul>
            </li>

          </ul>


        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>

  </head>

 <body  class="text-center">
  <br >
  <br >
  <br >
  <br >
  <br >
  <br >

  <div class="gallery">
    <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" fill="currentColor" class="bi bi-person-lines-fill" viewBox="0 0 16 16">
    <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm-5 6s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zM11 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5zm.5 2.5a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1h-4zm2 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2zm0 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2z"/>
    </svg>
    <div class="desc" ><a class="btn btn-primary" href="solicitud/index.php" class="text-sm-center" ><i class="fa fa-download"></i> SOLICITUDES</a></div>
  </div>


  <div class="gallery">
    <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" fill="currentColor" class="bi bi-graph-up-arrow" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm10 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-1 0V4.9l-3.613 4.417a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61L13.445 4H10.5a.5.5 0 0 1-.5-.5Z"/>
    </svg>
    <div class="desc"><a class="btn btn-primary" href="../reportes_solicitud/index.php"><i class="fa fa-download"></i> ADMINISTRACION DE MASCOTAS</a></div>
  </div>

  <div class="gallery">
    <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" fill="currentColor" class="bi bi-clipboard-data" viewBox="0 0 16 16">
    <path d="M4 11a1 1 0 1 1 2 0v1a1 1 0 1 1-2 0v-1zm6-4a1 1 0 1 1 2 0v5a1 1 0 1 1-2 0V7zM7 9a1 1 0 0 1 2 0v3a1 1 0 1 1-2 0V9z"/>
    <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"/>
    <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"/>
    </svg>
    <div class="desc" ><a class="btn btn-primary" href="../reportes_solicitud/index.php"><i class="fa fa-download"></i> REPORTES DE SOLICITUD</a></div>
  </div>
</div>

    




    <!-- JavaScript -->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../assets/js/sweetAler.js"></script>

  </body>

  </html>

<?php
} else {
  header('Location: ../login.php'); 
  die();
}

?>