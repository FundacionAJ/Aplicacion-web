<?php session_start();

if (isset($_SESSION['usuario'])) {

	require '../conexion.php';
	require '../funciones.php';

	$email_sesion = $_SESSION['usuario'];
	$query_sesion = $conexion->prepare("SELECT * FROM usuarios WHERE correo ='$email_sesion'");
	$query_sesion->execute();
	$sesion_usuarios = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
	foreach ($sesion_usuarios as $sesion_usuario) {
		$sobrenombre = $sesion_usuario['sobrenombre'];
	}
?>

	<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta name="description" content="">
		<meta name="author" content="">


		<title>Fundación Albornoz Jiménez A.C.</title>

		<!-- CSS -->
		<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="../assets/css/estilos.css">
		<link rel="shorcut icon" type="image/x-icon" href="../assets/imagenes/Fundacion.ico">
		<!-- SCRIPTS JS-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="peticion.js"></script>
	</head>

	<body>

		<!-- Fixed navbar -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.php">FAJ</a>
				</div>
				<div id="navbar" class="navbar-collapse collapse">
					<ul class="nav navbar-nav pull-right">
						<li>
							<a href="../carrito.php" class="btn">Solicitudes <span class="badge"><?php print cantidadMascota(); ?></span></a>
						</li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="usuario/solicitud/index.php">Mis solicitudes</a></li>
								<li><a href="usuario/actualizar_usuario.php">Mis datos</a></li>
								<li><a href="usuario/actualizar_clave.php">Cambiar contraseña</a></li>
								<li><a href="usuario/eliminar_cuenta.php">Eliminar cuenta</a></li>
								<li><a href="../Cerrar_session.php">Salir</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!--/.nav-collapse -->
			</div>
		</nav>



		<div class="container" id="main">
			<div class="main-form">
				<div class="row">
					<div class="col-md-12">
						<fieldset>
							<div class="form-group">
								<input type="text" class="form-control" name="busqueda" id="busqueda" placeholder="Buscar por especie o nombre de la mascota" style="text-align: center;">
							</div>
						</fieldset>
					</div>
				</div>
			</div>
		</div> <!-- /container -->


		<div class="container">
			<div class="row  justify-content-center">
				<div id="tabla_resultado">
					<!-- AQUI SE DESPLEGARA NUESTRA  DE CONSULTA -->
				</div>
			</div>
		</div>

	</body>
	<!--  JavaScript-->
	<script src="../assets/js/jquery.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>

	</html>
<?php
} else {
	header('Location: ../login.php'); 
  die();
}

?>