<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="assets/imagenes/Fundacion.ico">
</head>

<!-- Fixed navbar -->
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">FAJ</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav pull-right">
                <li class="active">
                    <a href="index.php" class="btn">Términos y condiciones</a>
                </li>
                <li>
                    <a href="dashboard.php" class="btn">Mascotas</a>
                </li>
                <li>
                    <a href="login.php" class="btn">Iniciar sesión</a>
                </li>
                <li>
                    <a href="registro.php" class="btn">Registrarse</a>
                </li>
            </ul>
        </div>
        <!--/.nav-collapse -->
    </div>
</nav>

<body>

    <!--img-->
    <div class="container px-5 px-lg-5 mt-5" id="main">
        <div class="row gx-5 gx-lg-5 row-cols-2 justify-content-center">
            <div class="text-center">
                <img src="assets/imagenes/FundacionAJ.jpg" class="rounded mx-auto d-block img-thumbnail" alt="..."><br><br>
            </div>
            <!--cards-->
            <!-- Acerca de -->
            <div class="col 12 ">
                <div class="panel panel-default">
                    <div class="panel-heading panel-info">
                        <h3 class=" text-center ">Condiciones de uso</h3>
                    </div>
                    <div class="class= card h-100">
                        <div class="card-body p-4 ">
                            <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                                Por favor lea cuidadosamente estas condiciones de uso antes de acceder,
                                navegar y/o hacer uso de cualquier parte de este sitio web.
                                <br> <br>
                                Estas condiciones de uso se aplican a todas las visitas al Sitio y usos
                                del mismo, así como al contenido y los servicios que se proporcionan en
                                él o a través de él. Al acceder al Sitio y hacer uso de él, usted manifiesta
                                que está de acuerdo totalmente con los Términos. Si no acepta todas las
                                Condiciones del servicio incluidas en este Acuerdo, no debería, ni le está
                                permitido, utilizar los Servicios.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading panel-info">
                    <h3 class=" text-center ">Identidad del titular del sitio web</h3>
                </div>
                <div class="class= card h-100">
                    <div class="card-body p-4 ">
                        <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                            El titular del Sitio es la Fundación Albornoz Jiménez A.C.,
                            domiciliada, Chapultepec Morales, Granada, Miguel Hidalgo,
                            11520 Ciudad de México, CDMX y dirección de correo electrónico
                            FundacionAlbornozJimenez@gmail.com.
                        </p>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading panel-info">
                    <h3 class=" text-center ">Modificaciones en este Acuerdo</h3>
                </div>
                <div class="class= card h-100">
                    <div class="card-body p-4 ">
                        <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                            Fundación Albornoz Jiménez A.C. se reserva el derecho de modificar
                            estas Condiciones del servicio y la política de privacidad con previo
                            aviso. Lo haremos notificando que han cambiado por medio de su correo
                            electrónico. Es su responsabilidad consultar las modificaciones de este
                            Acuerdo y familiarizarte con ellas.
                        </p>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading panel-info">
                    <h3 class=" text-center ">Uso de los Servicios</h3>
                </div>
                <div class="class= card h-100">
                    <div class="card-body p-4 ">
                        <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                            Debe cumplir con la mayoría de edad para utilizar el sitio web,
                            es algo imprescindible. Podrá pensar que no pasa nada porque ya
                            casi cumple con la mayoría de edad, pero sentimos decirte que eso no basta.
                        </p>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading panel-info">
                    <h3 class=" text-center ">Limitaciones en el uso</h3>
                </div>
                <div class="class= card h-100">
                    <div class="card-body p-4 ">
                        <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                            Cuando accede o usa el sitio web, no puede realizar las siguientes acciones.
                            <br><br>
                            (1) Cambiar o usar cualquier sección o interfaz del sitio web que no esté
                            disponible públicamente.
                            <br>
                            (2) investigar, explorar o probar un sistema o red (por ejemplo, para identificar
                            vulnerabilidades del sistema) o para evadir, dañar o corromper una medida de
                            seguridad o autentificación.
                            <br>
                            (3) deberá acceder al sistema únicamente interfaces proporcionadas (y solo de
                            acuerdo con los términos de servicio correspondientes).
                            <br>
                            (4) extraer información (hacer web scraping) de los Servicios.
                            <br>
                            (5) dificultar o interrumpir el acceso al Servicio (por ejemplo, hacer DOS attack,
                            DDOS attack, etc.) de cualquier usuario, host o red, lo que incluye, entre otras
                            acciones, enviar virus y spam a los Servicios, sobrecargarlos o usar scripts que
                            puedan interferir en la utilización de los Servicios o crear una carga excesiva en ellos.
                        </p>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading panel-info">
                    <h3 class=" text-center ">Registro y seguridad</h3>
                </div>
                <div class="class= card h-100">
                    <div class="card-body p-4 ">
                        <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                            Para usar ciertos servicios, debe crear una cuenta, proporcionar
                            su nombre completo, dirección de correo electrónico, número de teléfono,
                            domicilio, seleccionar una contraseña y un sobrenombre (nombre de usuario)
                            que coincida con sus estándares.
                            Acepta proporcionar información precisa, completa y actualizada sobre su
                            registro, especialmente su dirección de correo electrónico.
                            <br><br>
                            Es importante tener una dirección de correo electrónico precisa y actualizada
                            asociada a su cuenta. Si olvida su contraseña o es víctima de un ataque de phishing,
                            la única forma de recuperar su cuenta es con su dirección de correo electrónico.
                            Usted es responsable de mantener en secreto la contraseña de su cuenta y, para mantener
                            su cuenta segura, debe notificarnos de inmediato que ha perdido o sospechado que ha perdido
                            su cuenta o contraseña.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- /container -->

    <!----------- Footer ------------>
    <footer>
        <table class="table footer-table footer-table-td">
            <tbody>
                <tr>
                    <td><a class="a" style="text-decoration: none;" href="terminos&condiciones.php">Terminos & Condiciones</a></td>
                    <td><a class="a" style="text-decoration: none;" href="privacidad.php">Politica de privacidad</a></td>
                    <td><a class="a" style="text-decoration: none;" href="index.php">Acerca de</a></td>
                    <td><a class="a" style="text-decoration: none;" href="soporte.php">Ayuda</a></td>
                </tr>
                <tr>
                    <td><a class="a" style="text-decoration: none;" href="https://www.facebook.com/Fundaci%C3%B3n-Albornoz-Jim%C3%A9nez-1000658333438569/" target="_blank">Facebook</a></td>
                    <td><a class="a" style="text-decoration: none;" href="https://twitter.com/fundacion_j?t=h69P53_6IAjIUPqhJycW7Q&s=09" target="_blank">Twitter </a></td>
                    <td><a class="a" style="text-decoration: none;"> instagram </a></li>
                    <td>
                        <p class="a" style="text-decoration: none;"> Copyright (c) 2021</p>
                        </li>
                </tr>
            </tbody>
        </table>
    </footer>

    <!-- JavaScript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>