<?php session_start();

if (isset($_SESSION['administrador'])) {

  require '../conexion.php';
  $email_sesion = $_SESSION['administrador'];
  $query_sesion = $conexion->prepare("SELECT * FROM administrador WHERE correo ='$email_sesion'");
  $query_sesion->execute();
  $sesion_administradores = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
  foreach ($sesion_administradores as $sesion_administrador) {
    $sobrenombre = $sesion_administrador['sobrenombre'];
  }
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundacion Albornoz Jimenez A.C.</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="../assets/imagenes/Fundacion.ico">
    <link rel="stylesheet" type="text/css" href="../DataTables/datatables.min.css" />
    <link rel="stylesheet" type="text/css" href="../DataTables/Responsive-2.2.9/css/responsive.dataTables.min.css" />
    <link rel="icon" href="../assets/imagenes/logo.ico">
  </head>

  <body>


    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../panel/administrador.php">Regresar</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li>
              <a href="../panel/solicitud/index.php" class="btn">Solicitudes</a>
            </li>
            <!-- <li class="active">
            <a href="index.php" class="btn">Reportes de Solicitudes</a>
          </li> -->
            <li class="dropdown">
              <a href="index.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php print "Reportes de Solicitudes"; ?><span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="../reportes_solicitud/index.php">GENERAL</a></li>
                <li><a href="../reportes_solicitud/index_aceptadas.php">ACEPTADAS</a></li>
                <li class="active"><a href="../reportes_solicitud/index_rechazadas.php">RECHAZADAS</a></li>
              </ul>
            </li>
            <li>
              <a href="../help/index.php" class="btn">Reportes de ayuda</a>
            </li>
            <li>
              <a href="../panel/mascota/index.php" class="btn">Administar Mascotas</a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="../panel/administrador/actualizar_administrador.php">Mis datos</a></li>
                <li><a href="../panel/administrador/actualizar_clave.php">Cambiar contraseña</a></li>
                <li><a href="../Cerrar_session.php">Salir</a></li>
              </ul>
            </li>

          </ul>
        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">
      <div class="row">
        <div class="col-md-12">
          <fieldset>
            <legend>REPORTE DE SOLICITUDES RECHAZADAS</legend>

            <table id="tablax" class="table table-bordered display responsive nowrap" cellspacing="0">
              <thead>
                <tr>
                  <th>#</th>

                  <th>Postulado</th>
                  <th>N° Solicitud</th>
                  <th>Total</th>
                  <th>Fecha</th>
                  <th>Estatus</th>

                </tr>
              </thead>
              <tbody>
                <?php
                require '../vendor/autoload.php';
                $solicitud = new fundacion\Reportes;

                $info_solicitud = $solicitud->reportes_rechazadas();

                $cantidad = count($info_solicitud);
                if ($cantidad > 0) {
                  $c = 0;
                  for ($i = 0; $i < $cantidad; $i++) {
                    $c++;
                    $item = $info_solicitud[$i];
                ?>


                    <tr>

                      <td><?php print $c ?></td>

                      <td><?php print $item['nombre_usuario'] ?></td>
                      <td><?php print $item['id'] ?></td>
                      <td><?php print $item['total'] ?> </td>
                      <td><?php print $item['fecha'] ?></td>
                      <td><?php print $item['nombre'] ?></td>



                    </tr>

                  <?php
                  }
                } else {

                  ?>
                  <tr>
                    <td colspan="6">NO HAY REGISTROS</td>
                  </tr>

                <?php } ?>


              </tbody>

            </table>
          </fieldset>
          <br>
          <br>
          <p>Descargar el Reporte:
            <a class="btn btn-primary" href="reporte_rechazado.php"><i class="glyphicon glyphicon-download-alt"></i> Descargar</a>
          </p>
        </div>
      </div>


    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- Data tables -->

    <script type="text/javascript" src="../DataTables/datatables.min.js"></script>
    <script type="text/javascript" src="../DataTables/Responsive-2.2.9/js/dataTables.responsive.min.js"></script>
    <script>
      $(document).ready(function() {
        $('#tablax').DataTable({
          responsive: true,
          language: {
            processing: "Tratamiento en curso...",
            search: "Buscar&nbsp;:",
            lengthMenu: "Agrupar de _MENU_ items",
            info: "Mostrando del item _START_ al _END_ de un total de _TOTAL_ items",
            infoEmpty: "No existen datos.",
            infoFiltered: "(filtrado de _MAX_ elementos en total)",
            infoPostFix: "",
            loadingRecords: "Cargando...",
            zeroRecords: "No se encontraron datos con tu busqueda",
            emptyTable: "No hay datos disponibles en la tabla.",
            paginate: {
              first: "Primero",
              previous: "Anterior",
              next: "Siguiente",
              last: "Ultimo"
            },
            aria: {
              sortAscending: ": active para ordenar la columna en orden ascendente",
              sortDescending: ": active para ordenar la columna en orden descendente"
            },
          }
        });
      });
    </script>
    <script type='text/javascript'>
      $(function() {
        $(document).bind("contextmenu", function(e) {
          return false;
        });
      });
    </script>
  </body>

  </html>

<?php
} else {
  header('Location: ../login.php');
  die();
}

?>