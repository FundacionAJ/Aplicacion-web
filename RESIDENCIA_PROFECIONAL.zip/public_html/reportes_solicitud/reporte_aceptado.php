<?php

ob_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=sub, initial-scale=1.0">
 
   <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
   <style>
      @page {
                margin: 100px 25px;
            }
            .watermark {
                position: fixed;

                bottom:   10cm;
                left:     5.5cm;

                /** Cambiar las dimensiones de la imagen **/
                width:    10cm;
                height:   10cm;

                /** Tu marca de agua debe estar detrás de cada contenido **/
                z-index:  -1000;
                opacity: 0.3;  
            }
         
          
        </style>
      


</head>
<body> 
<div class="watermark">
<img src= "../assets/imagenes/Fundacion.jpeg" height="100%" width="100%" />
        </div>

<div class="container" id="main">
    <div class="row">
      <div class="col-md-12">
        <fieldset>
          <legend>Reporte de Solicitudes Aceptadas</legend>
          <br>
          <br>
          <table id="tablax" class="table table-bordered display responsive nowrap" cellspacing="0">
            <thead>
              <tr>
                <th>#</th>
                <th>Postulado</th>
                <th>N° Solicitud</th>
                <th>Total</th>
                <th>Fecha    </th>
                <th>Etatus</th>
                
              </tr>
            </thead>
            <tbody>
              <?php
              require '../vendor/autoload.php';
              $solicitud = new fundacion\Reportes;
              
              $info_solicitud = $solicitud->reportes_aceptadas();

              $cantidad = count($info_solicitud);
              if ($cantidad > 0) {
                $c = 0;
                for ($i = 0; $i < $cantidad; $i++) {
                  $c++;
                  $item = $info_solicitud[$i];
              ?>


                  <tr>
                    <td><?php print $c ?></td>
                    <td><?php print $item['nombre_usuario'] ?></td>
                    <td><?php print $item['id'] ?></td>
                    <td><?php print $item['total'] ?> </td>
                    <td><?php print $item['fecha'   ] ?></td>
                    <td><?php print $item['nombre'] ?></td>

                  
                  </tr>

                <?php
                }
              } else {

                ?>
                <tr>
                  <td colspan="6">NO HAY REGISTROS</td>
                </tr>

              <?php } ?>


            </tbody>

          </table>
        </fieldset>
      </div>
    </div>
  </div> <!-- /container -->
  </body>

  
 
  
</html>


<?php
$html=ob_get_clean();
//  echo $html;
require_once ("../dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled' => true ));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('letter');
$name = 'Reporte-Solicitudes-Aceptadas-'.date('m-d-Y_hia');

$dompdf->render();
$dompdf->stream($name, array("Attachment" =>true));

?>
