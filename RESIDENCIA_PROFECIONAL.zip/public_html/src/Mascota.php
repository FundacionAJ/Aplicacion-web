<?php

namespace fundacion;

class Mascota
{

    private $config;
    private $cn = null;

    public function __construct()
    {

        $this->config = parse_ini_file(__DIR__ . '/../config.ini');

        $this->cn = new \PDO($this->config['dns'], $this->config['usuario'], $this->config['clave'], array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }

    public function registrar($_params)
    {
        $sql = "INSERT INTO `mascotas`(`nombre_m`,`sexo`,`color`,`edad`,`estatus_id`, `descripcion`, `foto`, `especie_id`,`raza`, `fecha`, `telefono_dueno_ant`, `nombre_dueno_ant`) 
        VALUES (:nombre_m,:sexo,:color,:edad,:estatus_id,:descripcion,:foto,:especie_id,:raza,:fecha,:telefono_dueno_ant ,:nombre_dueno_ant)";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":nombre_m" => $_params['nombre_m'],
            ":sexo" => $_params['sexo'],
            ":color" => $_params['color'],
            ":edad" => $_params['edad'],
            ":estatus_id" => $_params['estatus_id'],
            ":descripcion" => $_params['descripcion'],
            ":foto" => $_params['foto'],
            ":especie_id" => $_params['especie_id'],
            ":raza" => $_params['raza'],
            ":fecha" => $_params['fecha'],
            ":telefono_dueno_ant" => $_params['telefono_dueno_ant'],
            ":nombre_dueno_ant" => $_params['nombre_dueno_ant'],
        );

        if ($resultado->execute($_array))
            return true;

        return false;
    }

    public function actualizar($_params)
    {
        $sql = "UPDATE `mascotas` SET `nombre_m`=:nombre_m,`sexo`=:sexo,`color`=:color,`edad`=:edad,`estatus_id`=:estatus_id,`descripcion`=:descripcion,`foto`=:foto,`especie_id`=:especie_id,`raza`=:raza,`fecha`=:fecha,`telefono_dueno_ant`=:telefono_dueno_ant,`nombre_dueno_ant`=:nombre_dueno_ant  WHERE `id`=:id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":nombre_m" => $_params['nombre_m'],
            ":sexo" => $_params['sexo'],
            ":color" => $_params['color'],
            ":edad" => $_params['edad'],
            ":estatus_id" => $_params['estatus_id'],
            ":descripcion" => $_params['descripcion'],
            ":foto" => $_params['foto'],
            ":especie_id" => $_params['especie_id'],
            ":raza" => $_params['raza'],
            ":fecha" => $_params['fecha'],
            ":telefono_dueno_ant" => $_params['telefono_dueno_ant'],
            ":nombre_dueno_ant" => $_params['nombre_dueno_ant'],
            ":id" =>  $_params['id']
        );

        if ($resultado->execute($_array))
            return true;

        return false;
    }

    public function eliminar($id)
    {
        $sql = "DELETE FROM `mascotas` WHERE `id`=:id ";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":id" =>  $id
        );

        if ($resultado->execute($_array))
            return true;

        return false;
    }

    public function mostrar()
    {
        $sql = "SELECT m.id, nombre_m ,sexo, color, edad, nombre_s, descripcion, foto, nombre_e, raza, fecha, telefono_dueno_ant, nombre_dueno_ant FROM mascotas m
        
        INNER JOIN especies e ON m.especie_id = e.id 
        INNER JOIN estatus_mascotas s ON m.estatus_id = s.id_estatus 
        ORDER BY m.id DESC
        ";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }


    public function mostrarnodisponibles()
    {
        $sql = "SELECT m.id, nombre_m ,sexo, color, edad, nombre_s, descripcion, foto, nombre_e, raza, fecha, telefono_dueno_ant, nombre_dueno_ant FROM mascotas m
        INNER JOIN especies e ON m.especie_id = e.id 
        INNER JOIN estatus_mascotas s ON m.estatus_id = s.id_estatus 
        WHERE m.especie_id = e.id and m.estatus_id = 1 
        ORDER BY m.id DESC
        ";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }

    public function mostrardisponibles()
    {
        $sql = "SELECT m.id, nombre_m ,sexo, color, edad, nombre_s, descripcion, foto, nombre_e, raza, fecha, telefono_dueno_ant, nombre_dueno_ant FROM mascotas m
        INNER JOIN especies e ON m.especie_id = e.id 
        INNER JOIN estatus_mascotas s ON m.estatus_id = s.id_estatus 
        WHERE m.especie_id = e.id and m.estatus_id = 2 
        ORDER BY m.id DESC
        ";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }

    public function mostraradoptados()
    {
        $sql = "SELECT m.id, nombre_m ,sexo, color, edad, nombre_s, descripcion, foto, nombre_e, raza, fecha, telefono_dueno_ant, nombre_dueno_ant FROM mascotas m
        INNER JOIN especies e ON m.especie_id = e.id 
        INNER JOIN estatus_mascotas s ON m.estatus_id = s.id_estatus 
        WHERE m.especie_id = e.id and m.estatus_id = 3 
        ORDER BY m.id DESC
        ";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }


    public function mostrarPorId($id)
    {

        $sql = "SELECT m.id, nombre_m ,sexo, color, edad, nombre_s, descripcion, foto, nombre_e, raza, fecha, telefono_dueno_ant, nombre_dueno_ant 
        FROM mascotas m
        
        INNER JOIN especies e ON m.especie_id = e.id 
        INNER JOIN estatus_mascotas s ON m.estatus_id = s.id_estatus 
        WHERE m.id=:id";    

        $resultado = $this->cn->prepare($sql);
        $_array = array(
            ":id" =>  $id
        );

        if ($resultado->execute($_array))
            return $resultado->fetch();

        return false;
    }
    public function ConocerPorId($id)
    {

        $sql = "SELECT m.id, nombre_m ,sexo, color, edad, nombre_s, descripcion, foto, nombre_e, raza, fecha, telefono_dueno_ant, nombre_dueno_ant 
        FROM mascotas m
        
        INNER JOIN especies e ON m.especie_id = e.id 
        INNER JOIN estatus_mascotas s ON m.estatus_id = s.id_estatus 
        WHERE m.id=:id";    

        $resultado = $this->cn->prepare($sql);
        $_array = array(
            ":id" =>  $id
        );

        if ($resultado->execute($_array))
            return $resultado->fetch();

        return false;
    }
    
     public function mostrarPorEstatus()
    {
        $sql = "SELECT mascotas.id, nombre_m ,sexo, color, edad, estatus_id, descripcion, foto, especie_id, raza, fecha, telefono_dueno_ant, nombre_dueno_ant FROM mascotas , especies
        WHERE mascotas.especie_id = especies.id  and estatus_id = 2 ORDER BY mascotas.id DESC;
        ";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }
}
