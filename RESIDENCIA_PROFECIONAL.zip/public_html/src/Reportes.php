<?php

namespace fundacion;

class Reportes
{

    private $config;
    private $cn = null;

    public function __construct()
    {

        $this->config = parse_ini_file(__DIR__ . '/../config.ini');

        $this->cn = new \PDO($this->config['dns'], $this->config['usuario'], $this->config['clave'], array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }

   
   
    public function mostrar_reportes()

    {
        
        $sql = "SELECT s.id, p.nombre_usuario, total, fecha, estatus_solicitud_id ,es.nombre 
        FROM solicitudes s, postulados p, estatus_solicitud es 
        WHERE s.postulado_id = p.id  AND s.estatus_solicitud_id = es.id ORDER BY s.id ASC";




        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return  $resultado->fetchAll();

        return false;
    }
    public function reportes_aceptadas()

    {
        
        $sql = "SELECT s.id, p.nombre_usuario, total, fecha, estatus_solicitud_id ,es.nombre 
        FROM solicitudes s, postulados p, estatus_solicitud es 
        WHERE s.postulado_id = p.id  AND estatus_solicitud_id = '1'AND s.estatus_solicitud_id = es.id ORDER BY s.id ASC";




        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return  $resultado->fetchAll();

        return false;
    }
    public function reportes_rechazadas()

    {
        
        $sql = "SELECT s.id, p.nombre_usuario, total, fecha, estatus_solicitud_id ,es.nombre 
        FROM solicitudes s, postulados p, estatus_solicitud es 
        WHERE s.postulado_id = p.id AND estatus_solicitud_id = '3' AND s.estatus_solicitud_id = es.id ORDER BY s.id ASC";




        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return  $resultado->fetchAll();

        return false;
    }











}
