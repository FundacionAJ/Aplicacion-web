<?php

namespace fundacion;

class Postulado
{

    private $config;
    private $cn = null;

    public function __construct()
    {

        $this->config = parse_ini_file(__DIR__ . '/../config.ini');

        $this->cn = new \PDO($this->config['dns'], $this->config['usuario'], $this->config['clave'], array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }

    public function registrar($_params)
    {


        $sql = "INSERT INTO `postulados`(`nombre_usuario`, `correo`, `telefono`, `direccion`, `motivo`) 
        VALUES (:nombre_usuario,:correo,:telefono,:direccion,:motivo)";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":nombre_usuario" => $_params['nombre_usuario'],
            ":correo" => $_params['correo'],
            ":telefono" => $_params['telefono'],
            ":direccion" => $_params['direccion'],
            ":motivo" => $_params['motivo']
        );

        if ($resultado->execute($_array))
            return $this->cn->lastInsertId();

        return false;
    }
   
}
