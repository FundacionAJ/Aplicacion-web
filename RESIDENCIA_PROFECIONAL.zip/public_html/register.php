
<?php
//////// CONEXION A LA BASE DE DATOS /////////
include('conexion.php');


//////////REGISTRO NUEVO USUARIO ////////////
if (isset($_POST['registrarse'])) { //// SI SE PRESIONA EL BOTÓN "REGISTRARSE" OCURRE LO SIGUIENTE 

    $nombre_usuario = $_POST['nombre_usuario'];
    $sobrenombre = $_POST['sobrenombre'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $clave = $_POST['clave'];
    $clave2 = $_POST['clave2'];

    $clave = hash('sha512', $clave);
    $clave2 = hash('sha512', $clave2);

    $mensaje = '';


    $existente = $conexion->query("SELECT * FROM usuarios where nombre_usuario='$nombre_usuario' or correo='$correo'"); /// COMPROBAR SI EL YA ESTA REGISTRADO
    if ($existente->rowCount() > 0) /// SI EXISTE ENTONCES EL MENSAJE SERÁ:
    {
        $mensaje .= '<i style="color: red;">Este usuario ya existe</i>';
    } else if ($clave != $clave2) /// SI LAS CONTRASEÑAS NO COINCIDEN ENVIAR EL SIGUIENTE MENSAJE
    {
        $mensaje .= $error .= '<i style="color: red;"> Las contraseñas no coinciden</i>';
    } else /// SI EL USUARIO NO EXISTE, NI EL EMAIL, Y LAS CONTRASEÑAS COINCIDEN ENTONCES PROCEDER A INSERTAR
    {

        try {

            $nuevoUsuario = $conexion->prepare('INSERT INTO usuarios ( nombre_usuario, sobrenombre, correo, telefono, direccion, clave, estatus_actual_id, administrador_id, fecha) 
  VALUES ( :nombre_usuario, :sobrenombre, :correo, :telefono, :direccion, :clave, 1, 0, NOW() )');
            $nuevoUsuario->bindParam(':nombre_usuario', $nombre_usuario, PDO::PARAM_STR);
            $nuevoUsuario->bindParam(':sobrenombre', $sobrenombre, PDO::PARAM_STR);
            $nuevoUsuario->bindParam(':correo', $correo, PDO::PARAM_STR);
            $nuevoUsuario->bindParam(':telefono', $telefono, PDO::PARAM_STR);
            $nuevoUsuario->bindParam(':direccion', $direccion, PDO::PARAM_STR);
            $nuevoUsuario->bindParam(':clave', $clave, PDO::PARAM_STR);

            $ejecutar = $nuevoUsuario->execute();
        } catch (PDOException $error) { /// MENSAJE POR SI SURGE ALGÚN ERROR
            print 'ERROR: ' . $error->getMessage();
            $mensaje .= $error .= '<i> Las contraseñas no coinciden</i>';
        }
        if ($ejecutar) // MENSAJE DE EXITO
        {
            
$_SESSION['usuario'] = $correo;
            header('location: panel/index.php');

            $mensaje .= '<i style="color: green;">Usuario registrado exitosamente</i>';
        }
    }
}

?>
